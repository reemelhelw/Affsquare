<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'affsquare' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Tmo> kP<L5>|rDX71zvZE-Xg-t3BgXVL}i7pYP9o$f`g/1a2kie$i66lv?Um{T$i' );
define( 'SECURE_AUTH_KEY',  '~Cnj-OlrDjY>,WbA,f1uv$LZ42#/l&F`9bGX Gv{2+X~]EO[HrHgcs3/&BC+;~~6' );
define( 'LOGGED_IN_KEY',    '5T#O[1I7qfIzpIEe@ZCpB@8dqS^Or>g;V~-(O,FZO)4aCa|9c1,ZxXyfXuizf+T~' );
define( 'NONCE_KEY',        'm(fy_3|V1qacnuF[{iq 9#:**H|W>WunwUT[@lfLiF?3_t>7f`!9ELlfD&fG}j@Z' );
define( 'AUTH_SALT',        ')DZ-k,l5M@cX2;HS,5qan1<ZpU!7,28}6MuBhC0<$fOACsR4>Q#YZ}}CI_VFQ_HM' );
define( 'SECURE_AUTH_SALT', '2ET*/#o~l=O6?IUtdB8B)cN<Ka,`f#$J_-WrSG8O9jGW[VG%Sz_<>*}>F_`7VD85' );
define( 'LOGGED_IN_SALT',   ' IB7]1SR<BwJ:AB}9xF-M(~v7A?J*BOrPoOfM*}N#nE+>T:;CA_aR&D>N{A-+pv#' );
define( 'NONCE_SALT',       ':!_mWtx_9a`M)~e}[n N@9(C MFWQ>5c?)+D_^cPavdj@Ok[m.`^QCOd)}v^Q%sv' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
